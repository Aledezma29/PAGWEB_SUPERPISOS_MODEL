/* =============================================
   SUPER PISOS PANAMÁ – Catalog Filters JS
   ============================================= */
(function () {
    'use strict';

    // ─ PRODUCT DATA ─────────────────────────────
    const PRODUCTS = [
        { id: 1, name: 'Porcelanato Carrara Blanco', cat: 'porcelanato', price: 28.50, room: 'sala', finish: 'mate', use: 'interior', img: 'images/hero.png', rating: 4.8, reviews: 142, new: true, hot: false },
        { id: 2, name: 'Cerámica Terracotta 45x45', cat: 'ceramica', price: 12.90, room: 'cocina', finish: 'natural', use: 'interior', img: 'images/hero.png', rating: 4.6, reviews: 89, new: false, hot: true },
        { id: 3, name: 'Porcelanato Oslo Gris 60x60', cat: 'porcelanato', price: 32.00, room: 'sala', finish: 'pulido', use: 'interior', img: 'images/hero.png', rating: 4.9, reviews: 203, new: false, hot: true },
        { id: 4, name: 'Azulejo Mármol Blanco 30x60', cat: 'azulejo', price: 18.20, room: 'baño', finish: 'brillante', use: 'interior', img: 'images/hero.png', rating: 4.7, reviews: 67, new: true, hot: false },
        { id: 5, name: 'Piso Exterior Antideslizante', cat: 'exterior', price: 16.80, room: 'terraza', finish: 'mate', use: 'exterior', img: 'images/hero.png', rating: 4.5, reviews: 54, new: false, hot: false },
        { id: 6, name: 'Madera Laminada Roble Claro', cat: 'madera', price: 24.00, room: 'dormitorio', finish: 'natural', use: 'interior', img: 'images/hero.png', rating: 4.8, reviews: 98, new: true, hot: true },
        { id: 7, name: 'Vinílico SPC Concreto Gris', cat: 'vinilico', price: 22.50, room: 'cocina', finish: 'mate', use: 'interior', img: 'images/hero.png', rating: 4.6, reviews: 73, new: false, hot: false },
        { id: 8, name: 'Mosáico Veneciano Turquesa', cat: 'mosaico', price: 45.00, room: 'baño', finish: 'brillante', use: 'interior', img: 'images/hero.png', rating: 4.9, reviews: 31, new: true, hot: false },
        { id: 9, name: 'Porcelanato Madera Wengué', cat: 'porcelanato', price: 31.00, room: 'dormitorio', finish: 'natural', use: 'interior', img: 'images/hero.png', rating: 4.7, reviews: 118, new: false, hot: true },
        { id: 10, name: 'Cerámica Rustic Stone 33x33', cat: 'ceramica', price: 9.80, room: 'terraza', finish: 'mate', use: 'exterior', img: 'images/hero.png', rating: 4.4, reviews: 45, new: false, hot: false },
        { id: 11, name: 'Azulejo Subway Blanco 10x30', cat: 'azulejo', price: 8.50, room: 'cocina', finish: 'brillante', use: 'interior', img: 'images/hero.png', rating: 4.5, reviews: 182, new: false, hot: true },
        { id: 12, name: 'Piso Porcelanato Grande 90x90', cat: 'porcelanato', price: 38.00, room: 'sala', finish: 'pulido', use: 'interior', img: 'images/hero.png', rating: 4.9, reviews: 57, new: true, hot: false },
    ];

    let filters = { cat: 'all', priceMin: 0, priceMax: 100, room: 'all', finish: 'all', use: 'all', sort: 'relevance', search: '' };
    let currentPage = 1;
    const PER_PAGE = 9;

    const $ = (id) => document.getElementById(id);

    // ─ RENDER ────────────────────────────────────
    function getFiltered() {
        return PRODUCTS.filter(p => {
            if (filters.cat !== 'all' && p.cat !== filters.cat) return false;
            if (filters.room !== 'all' && p.room !== filters.room) return false;
            if (filters.finish !== 'all' && p.finish !== filters.finish) return false;
            if (filters.use !== 'all' && p.use !== filters.use) return false;
            if (p.price < filters.priceMin || p.price > filters.priceMax) return false;
            if (filters.search && !p.name.toLowerCase().includes(filters.search.toLowerCase())) return false;
            return true;
        }).sort((a, b) => {
            if (filters.sort === 'price-asc') return a.price - b.price;
            if (filters.sort === 'price-desc') return b.price - a.price;
            if (filters.sort === 'rating') return b.rating - a.rating;
            return 0; // relevance
        });
    }

    function renderStars(rating) {
        const full = Math.floor(rating);
        const half = rating % 1 >= 0.5;
        let s = '';
        for (let i = 0; i < full; i++) s += '★';
        if (half) s += '½';
        while (s.replace('½', '').length < 5) s += '☆';
        return s;
    }

    function renderProducts(filtered) {
        const grid = $('productGrid');
        const count = $('productCount');
        if (!grid) return;

        const start = (currentPage - 1) * PER_PAGE;
        const paginated = filtered.slice(start, start + PER_PAGE);

        if (count) count.textContent = filtered.length;

        if (paginated.length === 0) {
            grid.innerHTML = `<div class="no-results" style="grid-column:1/-1;text-align:center;padding:4rem 1rem;">
        <div style="font-size:3rem;margin-bottom:1rem;">🔍</div>
        <h3>No encontramos productos</h3>
        <p>Intenta ajustar tus filtros de búsqueda.</p>
        <button class="btn btn-outline-dark mt-4" onclick="clearAllFilters()">Limpiar filtros</button>
      </div>`;
            return;
        }

        grid.innerHTML = paginated.map(p => `
      <div class="product-card" data-reveal>
        <div class="product-card-img">
          <img data-src="${p.img}" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="${p.name}">
          <div class="product-card-badge">
            ${p.new ? '<span class="badge badge-primary">Nuevo</span>' : ''}
            ${p.hot ? '<span class="badge badge-dark">Popular</span>' : ''}
          </div>
          <div class="product-card-actions">
            <button class="product-action-btn" data-tooltip="Guardar" onclick="event.preventDefault()">♡</button>
            <button class="product-action-btn" data-tooltip="Cotizar" onclick="openQuote('${p.name}')">✉</button>
          </div>
        </div>
        <div class="product-card-body">
          <div class="product-card-category">${p.cat.charAt(0).toUpperCase() + p.cat.slice(1)}</div>
          <div class="product-card-name">${p.name}</div>
          <div class="product-card-rating">
            <span class="stars">${renderStars(p.rating)}</span>
            <span class="count">(${p.reviews})</span>
          </div>
          <div class="product-card-footer">
            <div class="product-card-price">
              <div class="amount">$${p.price.toFixed(2)}</div>
              <div class="unit">por m²</div>
            </div>
            <a href="contacto.html?producto=${encodeURIComponent(p.name)}" class="btn btn-primary btn-sm">Cotizar</a>
          </div>
        </div>
      </div>
    `).join('');

        // Re-observe lazy images
        grid.querySelectorAll('img[data-src]').forEach(img => {
            if ('IntersectionObserver' in window) {
                const io = new IntersectionObserver(entries => {
                    entries.forEach(e => { if (e.isIntersecting) { e.target.src = e.target.dataset.src; e.target.classList.add('loaded'); io.unobserve(e.target); } });
                }, { rootMargin: '200px' });
                io.observe(img);
            } else { img.src = img.dataset.src; img.classList.add('loaded'); }
        });

        renderPagination(filtered.length);
    }

    function renderPagination(total) {
        const pag = $('pagination');
        if (!pag) return;
        const pages = Math.ceil(total / PER_PAGE);
        if (pages <= 1) { pag.innerHTML = ''; return; }
        let html = '';
        if (currentPage > 1) html += `<button class="pag-btn" onclick="goPage(${currentPage - 1})">‹</button>`;
        for (let i = 1; i <= pages; i++) {
            html += `<button class="pag-btn${i === currentPage ? ' active' : ''}" onclick="goPage(${i})">${i}</button>`;
        }
        if (currentPage < pages) html += `<button class="pag-btn" onclick="goPage(${currentPage + 1})">›</button>`;
        pag.innerHTML = html;
    }

    window.goPage = (n) => { currentPage = n; renderProducts(getFiltered()); window.scrollTo({ top: 0, behavior: 'smooth' }); };

    function renderActiveFilters() {
        const container = $('activeFilters');
        if (!container) return;
        const chips = [];
        if (filters.cat !== 'all') chips.push({ label: `Categoría: ${filters.cat}`, clear: () => { filters.cat = 'all'; resetSelect('filterCat'); } });
        if (filters.room !== 'all') chips.push({ label: `Habitación: ${filters.room}`, clear: () => { filters.room = 'all'; resetSelect('filterRoom'); } });
        if (filters.finish !== 'all') chips.push({ label: `Acabado: ${filters.finish}`, clear: () => { filters.finish = 'all'; resetSelect('filterFinish'); } });
        if (filters.use !== 'all') chips.push({ label: `Uso: ${filters.use}`, clear: () => { filters.use = 'all'; resetSelect('filterUse'); } });
        if (filters.search) chips.push({ label: `Búsqueda: "${filters.search}"`, clear: () => { filters.search = ''; const s = $('catalogSearch'); if (s) s.value = ''; } });
        container.innerHTML = chips.map((c, i) =>
            `<span class="filter-chip">${c.label} <button onclick="removeChip(${i})">×</button></span>`
        ).join('');
        window._filterChips = chips;
        $('clearAllBtn').style.display = chips.length ? 'inline-flex' : 'none';
    }

    window.removeChip = (i) => { window._filterChips[i].clear(); refresh(); };
    window.clearAllFilters = () => {
        filters = { cat: 'all', priceMin: 0, priceMax: 100, room: 'all', finish: 'all', use: 'all', sort: 'relevance', search: '' };
        ['filterCat', 'filterRoom', 'filterFinish', 'filterUse'].forEach(resetSelect);
        const s = $('catalogSearch'); if (s) s.value = '';
        const pr = $('priceRange'); if (pr) { pr.value = pr.max; updatePriceDisplay(); }
        refresh();
    };

    function resetSelect(id) { const s = $(id); if (s) s.value = 'all'; }

    function refresh() { currentPage = 1; renderActiveFilters(); renderProducts(getFiltered()); }

    // ─ PRICE RANGE ──────────────────────────────
    const priceRange = $('priceRange');
    const priceDisplay = $('priceDisplay');
    function updatePriceDisplay() {
        const v = priceRange ? parseInt(priceRange.value) : 100;
        filters.priceMax = v;
        if (priceDisplay) priceDisplay.textContent = v === parseInt(priceRange.max) ? 'Todos' : `Hasta $${v}/m²`;
    }
    if (priceRange) { priceRange.addEventListener('input', () => { updatePriceDisplay(); refresh(); }); updatePriceDisplay(); }

    // ─ FILTER SELECTS ───────────────────────────
    [['filterCat', 'cat'], ['filterRoom', 'room'], ['filterFinish', 'finish'], ['filterUse', 'use']].forEach(([id, key]) => {
        const el = $(id);
        if (el) el.addEventListener('change', () => { filters[key] = el.value; refresh(); });
    });

    // ─ SORT ─────────────────────────────────────
    const sortEl = $('sortSelect');
    if (sortEl) sortEl.addEventListener('change', () => { filters.sort = sortEl.value; refresh(); });

    // ─ SEARCH ───────────────────────────────────
    const searchEl = $('catalogSearch');
    if (searchEl) {
        let searchTimer;
        searchEl.addEventListener('input', () => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => { filters.search = searchEl.value.trim(); refresh(); }, 300);
        });
    }

    // ─ QUOTE MODAL ──────────────────────────────
    window.openQuote = (productName) => {
        window.location.href = `contacto.html?producto=${encodeURIComponent(productName)}`;
    };

    // ─ INIT ─────────────────────────────────────
    if ($('productGrid')) refresh();

})();
