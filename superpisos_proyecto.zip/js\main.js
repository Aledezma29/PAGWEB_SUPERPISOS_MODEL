/* =============================================
   SUPER PISOS PANAMÁ – Main JavaScript
   ============================================= */

(function () {
  'use strict';

  // ── NAVBAR ────────────────────────────────────
  const navbar = document.getElementById('navbar');
  if (navbar) {
    const onScroll = () => {
      if (window.scrollY > 60) {
        navbar.classList.add('scrolled');
        navbar.classList.remove('transparent');
      } else {
        navbar.classList.remove('scrolled');
        navbar.classList.add('transparent');
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // ── HAMBURGER / MOBILE NAV ────────────────────
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobileNav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('open');
      mobileNav.classList.toggle('open');
      document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });
    mobileNav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        hamburger.classList.remove('open');
        mobileNav.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  // ── SCROLL TO TOP ─────────────────────────────
  const scrollTopBtn = document.getElementById('scrollTop');
  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      scrollTopBtn.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });
    scrollTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  // ── LAZY LOADING ──────────────────────────────
  const lazyImages = document.querySelectorAll('img[data-src]');
  if ('IntersectionObserver' in window) {
    const imgObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.add('loaded');
          imgObserver.unobserve(img);
        }
      });
    }, { rootMargin: '200px' });
    lazyImages.forEach(img => imgObserver.observe(img));
  } else {
    lazyImages.forEach(img => { img.src = img.dataset.src; img.classList.add('loaded'); });
  }

  // ── LEAD POPUP ───────────────────────────────
  const popup = document.getElementById('leadPopup');
  const popupClose = document.getElementById('popupClose');
  const popupForm = document.getElementById('popupForm');
  const POPUP_KEY = 'spp_popup_dismissed';

  if (popup && !localStorage.getItem(POPUP_KEY)) {
    // Show after 5 seconds
    setTimeout(() => popup.classList.add('active'), 5000);

    // Exit intent (desktop)
    document.addEventListener('mouseleave', (e) => {
      if (e.clientY < 0 && !popup.classList.contains('dismissed')) {
        popup.classList.add('active');
      }
    });

    if (popupClose) {
      popupClose.addEventListener('click', () => {
        popup.classList.remove('active');
        popup.classList.add('dismissed');
        localStorage.setItem(POPUP_KEY, '1');
      });
    }
    popup.addEventListener('click', (e) => {
      if (e.target === popup) {
        popup.classList.remove('active');
        popup.classList.add('dismissed');
        localStorage.setItem(POPUP_KEY, '1');
      }
    });

    if (popupForm) {
      popupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = popupForm.querySelector('input[type="email"]').value;
        document.getElementById('popupSuccess').innerHTML =
          `<div class="popup-success"><div class="popup-success-icon">✓</div><h3>¡Gracias!</h3><p>Tu descuento del 5% fue enviado a <strong>${email}</strong></p></div>`;
        popupForm.style.display = 'none';
        localStorage.setItem(POPUP_KEY, '1');
      });
    }
  }

  // ── WHATSAPP FLOAT ───────────────────────────
  // (button is in HTML, functionality via href)

  // ── COUNTER ANIMATION ────────────────────────
  const counters = document.querySelectorAll('[data-count]');
  if (counters.length) {
    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseInt(el.dataset.count, 10);
          const suffix = el.dataset.suffix || '';
          const duration = 1800;
          const step = target / (duration / 16);
          let current = 0;
          const timer = setInterval(() => {
            current += step;
            if (current >= target) { current = target; clearInterval(timer); }
            el.textContent = Math.floor(current).toLocaleString() + suffix;
          }, 16);
          counterObserver.unobserve(el);
        }
      });
    }, { threshold: 0.5 });
    counters.forEach(c => counterObserver.observe(c));
  }

  // ── SCROLL REVEAL ────────────────────────────
  const reveals = document.querySelectorAll('[data-reveal]');
  if (reveals.length && 'IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-up');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    reveals.forEach(el => revealObserver.observe(el));
  }

  // ── TESTIMONIAL CAROUSEL ─────────────────────
  const testimonialSlider = document.getElementById('testimonialSlider');
  if (testimonialSlider) {
    const track = testimonialSlider.querySelector('.slider-track');
    const slides = testimonialSlider.querySelectorAll('.slider-slide');
    const prev = document.getElementById('testimonialPrev');
    const next = document.getElementById('testimonialNext');
    let current = 0;
    const total = slides.length;

    const goTo = (index) => {
      current = (index + total) % total;
      track.style.transform = `translateX(-${current * 100}%)`;
      testimonialSlider.querySelectorAll('.slider-dot').forEach((d, i) =>
        d.classList.toggle('active', i === current));
    };

    if (prev) prev.addEventListener('click', () => goTo(current - 1));
    if (next) next.addEventListener('click', () => goTo(current + 1));

    // Dots
    const dotContainer = document.getElementById('testimonialDots');
    if (dotContainer) {
      slides.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
        dot.addEventListener('click', () => goTo(i));
        dotContainer.appendChild(dot);
      });
    }

    // Auto-play
    let autoPlay = setInterval(() => goTo(current + 1), 5000);
    testimonialSlider.addEventListener('mouseenter', () => clearInterval(autoPlay));
    testimonialSlider.addEventListener('mouseleave', () => { autoPlay = setInterval(() => goTo(current + 1), 5000); });
  }

  // ── SMOOTH TABS ──────────────────────────────
  document.querySelectorAll('.tab-nav').forEach(nav => {
    nav.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tabId = btn.dataset.tab;
        const container = btn.closest('[data-tabs]') || btn.closest('.tabs-container') || document;
        container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        container.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        const pane = container.querySelector(`#${tabId}`);
        if (pane) pane.classList.add('active');
      });
    });
  });

  // ── ACTIVE NAV LINK ──────────────────────────
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && href.includes(currentPage)) link.classList.add('active');
  });

})();
