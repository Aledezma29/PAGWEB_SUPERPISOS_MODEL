/* =============================================
   SUPER PISOS PANAMÁ – Before/After Gallery JS
   ============================================= */
(function () {
    'use strict';

    document.querySelectorAll('.before-after').forEach(container => {
        const slider = container.querySelector('.ba-slider');
        const before = container.querySelector('.ba-before');
        const handle = container.querySelector('.ba-handle');
        if (!slider || !before) return;

        let isDragging = false;

        function setPosition(x) {
            const rect = container.getBoundingClientRect();
            let pct = ((x - rect.left) / rect.width) * 100;
            pct = Math.max(2, Math.min(98, pct));
            before.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
            if (handle) handle.style.left = pct + '%';
        }

        // Mouse
        container.addEventListener('mousedown', (e) => { isDragging = true; setPosition(e.clientX); });
        window.addEventListener('mousemove', (e) => { if (isDragging) setPosition(e.clientX); });
        window.addEventListener('mouseup', () => { isDragging = false; });

        // Touch
        container.addEventListener('touchstart', (e) => { isDragging = true; setPosition(e.touches[0].clientX); }, { passive: true });
        window.addEventListener('touchmove', (e) => { if (isDragging) setPosition(e.touches[0].clientX); }, { passive: true });
        window.addEventListener('touchend', () => { isDragging = false; });

        // Set initial position
        setPosition(container.getBoundingClientRect().left + container.offsetWidth * 0.5);
    });

    // ─ GALLERY FILTER ────────────────────────────
    const filterBtns = document.querySelectorAll('.gallery-filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const filter = btn.dataset.filter;
            galleryItems.forEach(item => {
                const match = filter === 'all' || item.dataset.room === filter;
                item.style.display = match ? 'block' : 'none';
                if (match) item.style.animation = 'fadeIn 0.4s ease both';
            });
        });
    });

})();
