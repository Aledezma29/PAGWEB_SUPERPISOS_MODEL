<?php
/**
 * Super Pisos Panamá – functions.php
 * Enqueues styles/scripts, registers menus, thumbnail support
 * and custom post types: Productos, Proyectos, Tiendas.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SUPERPISOS_VERSION', '1.0.0' );

// ─ THEME SETUP ───────────────────────────────────────────────────────────
function superpisos_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form','comment-form','gallery','caption' ] );
    add_theme_support( 'responsive-embeds' );

    register_nav_menus([
        'primary'  => __( 'Menú Principal', 'superpisos' ),
        'footer'   => __( 'Menú Pie de Página', 'superpisos' ),
    ]);
}
add_action( 'after_setup_theme', 'superpisos_setup' );

// ─ ENQUEUE ASSETS ────────────────────────────────────────────────────────
function superpisos_assets() {
    // Google Fonts
    wp_enqueue_style( 'superpisos-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&display=swap',
        [], null );

    // CSS
    wp_enqueue_style( 'superpisos-variables', get_template_directory_uri() . '/assets/css/variables.css', [], SUPERPISOS_VERSION );
    wp_enqueue_style( 'superpisos-global',    get_template_directory_uri() . '/assets/css/global.css',    ['superpisos-variables'], SUPERPISOS_VERSION );
    wp_enqueue_style( 'superpisos-components',get_template_directory_uri() . '/assets/css/components.css',['superpisos-global'],    SUPERPISOS_VERSION );
    wp_enqueue_style( 'superpisos-main',      get_stylesheet_uri(),                                        ['superpisos-components'],SUPERPISOS_VERSION );

    // JS
    wp_enqueue_script( 'superpisos-main', get_template_directory_uri() . '/assets/js/main.js', [], SUPERPISOS_VERSION, true );

    // Page-specific scripts
    if ( is_page_template( 'page-calculadora.php' ) )
        wp_enqueue_script( 'superpisos-calc', get_template_directory_uri() . '/assets/js/calculator.js', ['superpisos-main'], SUPERPISOS_VERSION, true );

    if ( is_page_template( 'page-catalogo.php' ) )
        wp_enqueue_script( 'superpisos-catalog', get_template_directory_uri() . '/assets/js/catalog.js', ['superpisos-main'], SUPERPISOS_VERSION, true );

    if ( is_page_template( 'page-galeria.php' ) )
        wp_enqueue_script( 'superpisos-gallery', get_template_directory_uri() . '/assets/js/gallery.js', ['superpisos-main'], SUPERPISOS_VERSION, true );

    if ( is_page_template( 'page-tiendas.php' ) ) {
        wp_enqueue_style(  'leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4' );
        wp_enqueue_script( 'leaflet-js',  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',  [], '1.9.4', true );
    }
}
add_action( 'wp_enqueue_scripts', 'superpisos_assets' );

// ─ CUSTOM POST TYPES ─────────────────────────────────────────────────────
function superpisos_register_cpts() {

    // PRODUCTOS
    register_post_type( 'producto', [
        'labels'      => [
            'name'          => 'Productos',
            'singular_name' => 'Producto',
            'add_new_item'  => 'Añadir Producto',
            'edit_item'     => 'Editar Producto',
        ],
        'public'      => true,
        'has_archive' => true,
        'menu_icon'   => 'dashicons-store',
        'supports'    => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'     => [ 'slug' => 'catalogo' ],
        'show_in_rest'=> true,
    ]);

    // PROYECTOS (Galería)
    register_post_type( 'proyecto', [
        'labels'      => [
            'name'          => 'Proyectos',
            'singular_name' => 'Proyecto',
            'add_new_item'  => 'Añadir Proyecto',
        ],
        'public'      => true,
        'has_archive' => true,
        'menu_icon'   => 'dashicons-images-alt2',
        'supports'    => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
        'rewrite'     => [ 'slug' => 'proyectos' ],
        'show_in_rest'=> true,
    ]);

    // TIENDAS
    register_post_type( 'tienda', [
        'labels'      => [
            'name'          => 'Tiendas',
            'singular_name' => 'Tienda',
            'add_new_item'  => 'Añadir Tienda',
        ],
        'public'      => true,
        'menu_icon'   => 'dashicons-location-alt',
        'supports'    => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
        'show_in_rest'=> true,
    ]);
}
add_action( 'init', 'superpisos_register_cpts' );

// ─ CUSTOM TAXONOMIES ─────────────────────────────────────────────────────
function superpisos_register_taxonomies() {
    register_taxonomy( 'categoria_producto', 'producto', [
        'label'        => 'Categorías',
        'hierarchical' => true,
        'rewrite'      => [ 'slug' => 'categoria' ],
        'show_in_rest' => true,
    ]);
    register_taxonomy( 'tipo_habitacion', 'producto', [
        'label'        => 'Habitación',
        'hierarchical' => false,
        'show_in_rest' => true,
    ]);
    register_taxonomy( 'tipo_acabado', 'producto', [
        'label'        => 'Acabado',
        'hierarchical' => false,
        'show_in_rest' => true,
    ]);
}
add_action( 'init', 'superpisos_register_taxonomies' );

// ─ SCHEMA MARKUP HELPER ──────────────────────────────────────────────────
function superpisos_local_business_schema() {
    $schema = [
        '@context'  => 'https://schema.org',
        '@type'     => 'LocalBusiness',
        'name'      => 'Super Pisos Panamá',
        'url'       => home_url(),
        'telephone' => '+507-6999-9999',
        'email'     => 'info@superpisos.com.pa',
        'address'   => [
            '@type'           => 'PostalAddress',
            'addressCountry'  => 'PA',
            'addressLocality' => 'Ciudad de Panamá',
            'streetAddress'   => 'Av. Ricardo J. Alfaro, Plaza Centenario, Local 15',
        ],
        'openingHours' => 'Mo-Sa 08:00-18:00',
        'image'        => get_theme_mod( 'superpisos_og_image', get_template_directory_uri() . '/assets/images/hero.png' ),
    ];
    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>' . "\n";
}
add_action( 'wp_head', 'superpisos_local_business_schema' );

function superpisos_product_schema( $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    if ( get_post_type( $post_id ) !== 'producto' ) return;
    $price = get_post_meta( $post_id, '_precio', true ) ?: '0';
    $schema = [
        '@context' => 'https://schema.org',
        '@type'    => 'Product',
        'name'     => get_the_title( $post_id ),
        'image'    => get_the_post_thumbnail_url( $post_id, 'full' ),
        'description' => get_the_excerpt( $post_id ),
        'brand'    => [ '@type' => 'Brand', 'name' => 'Super Pisos Panamá' ],
        'offers'   => [
            '@type'         => 'Offer',
            'price'         => $price,
            'priceCurrency' => 'USD',
            'availability'  => 'https://schema.org/InStock',
            'seller'        => [ '@type' => 'Organization', 'name' => 'Super Pisos Panamá' ],
        ],
    ];
    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}

// ─ SEO META TAGS ─────────────────────────────────────────────────────────
function superpisos_seo_meta() {
    if ( is_singular( 'producto' ) ) {
        $desc = get_the_excerpt() ?: get_post_meta( get_the_ID(), '_meta_description', true );
        echo '<meta name="description" content="' . esc_attr( wp_strip_all_tags( $desc ) ) . '">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr( get_the_title() . ' | Super Pisos Panamá' ) . '">' . "\n";
        echo '<meta property="og:type" content="product">' . "\n";
        echo '<meta property="og:image" content="' . esc_url( get_the_post_thumbnail_url( null, 'large' ) ) . '">' . "\n";
        superpisos_product_schema();
    } elseif ( is_front_page() ) {
        echo '<meta name="description" content="Líder en pisos, azulejos, revestimientos y ventanas en Panamá. Porcelanato, cerámica, madera laminada y más. Cotiza gratis.">' . "\n";
    }
}
add_action( 'wp_head', 'superpisos_seo_meta' );

// ─ EXCERPT LENGTH ────────────────────────────────────────────────────────
add_filter( 'excerpt_length', fn() => 20, 999 );
add_filter( 'excerpt_more',   fn() => '…' );

// ─ IMAGE SIZES ───────────────────────────────────────────────────────────
add_image_size( 'product-card', 480, 360, true );
add_image_size( 'hero',         1920, 880, true );
add_image_size( 'blog-card',    720, 405, true  );

// ─ ELEMENTOR COMPATIBILITY ────────────────────────────────────────────────
add_action( 'elementor/widgets/register', function() {
    // Elementor widgets can be registered here
});
