/* =============================================
   SUPER PISOS PANAMÁ – Material Calculator JS
   ============================================= */

(function () {
    'use strict';

    const PRODUCTS = {
        porcelain: { name: 'Porcelanato', priceMin: 12, priceMax: 35, boxCoverage: 1.44 },
        ceramic: { name: 'Cerámica', priceMin: 6, priceMax: 18, boxCoverage: 1.00 },
        wood: { name: 'Madera Laminada', priceMin: 18, priceMax: 45, boxCoverage: 1.85 },
        vinyl: { name: 'Vinílico / SPC', priceMin: 14, priceMax: 28, boxCoverage: 2.23 },
        exterior: { name: 'Piso Exterior', priceMin: 8, priceMax: 22, boxCoverage: 1.00 },
        azulejo: { name: 'Azulejo Pared', priceMin: 5, priceMax: 20, boxCoverage: 1.00 },
    };

    const WASTE_RATES = { 5: 0.05, 10: 0.10, 15: 0.15 };

    let step = 1;
    let calcData = { room: '', length: 0, width: 0, product: '', waste: 10 };

    const $ = (id) => document.getElementById(id);

    // ─ STEP NAVIGATION ─────────────────────────────
    function showStep(n) {
        step = n;
        document.querySelectorAll('.calc-step').forEach(s => {
            s.classList.toggle('active', parseInt(s.dataset.step) === n);
        });
        document.querySelectorAll('.calc-progress-dot').forEach((d, i) => {
            d.classList.toggle('completed', i < n - 1);
            d.classList.toggle('active', i === n - 1);
        });
        $('calcStepLabel').textContent = `Paso ${n} de 3`;
        $('calcPrev').style.display = n > 1 ? 'flex' : 'none';
        $('calcNext').style.display = n < 3 ? 'flex' : 'none';
        $('calcSubmit').style.display = n === 3 ? 'flex' : 'none';
    }

    function validateStep(n) {
        if (n === 1 && !calcData.room) {
            showCalcError('Por favor selecciona un tipo de habitación.'); return false;
        }
        if (n === 2) {
            if (!calcData.length || calcData.length <= 0 || !calcData.width || calcData.width <= 0) {
                showCalcError('Ingresa dimensiones válidas mayores a 0.'); return false;
            }
        }
        if (n === 3 && !calcData.product) {
            showCalcError('Por favor selecciona un tipo de material.'); return false;
        }
        hideCalcError(); return true;
    }

    function showCalcError(msg) {
        let err = document.querySelector('.calc-error');
        if (!err) {
            err = document.createElement('p');
            err.className = 'calc-error';
            err.style.cssText = 'color:#E03E3E;font-size:.875rem;margin-top:.5rem;';
        }
        err.textContent = msg;
        const active = document.querySelector('.calc-step.active');
        if (active && !active.querySelector('.calc-error')) active.appendChild(err);
    }
    function hideCalcError() {
        document.querySelectorAll('.calc-error').forEach(e => e.remove());
    }

    // ─ ROOM SELECTION ──────────────────────────────
    document.querySelectorAll('.room-card').forEach(card => {
        card.addEventListener('click', () => {
            document.querySelectorAll('.room-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            calcData.room = card.dataset.room;
        });
    });

    // ─ DIMENSION INPUTS ────────────────────────────
    const lengthInput = $('calcLength');
    const widthInput = $('calcWidth');
    const areaDisplay = $('calcArea');

    function updateArea() {
        calcData.length = parseFloat(lengthInput?.value) || 0;
        calcData.width = parseFloat(widthInput?.value) || 0;
        const area = calcData.length * calcData.width;
        if (areaDisplay) areaDisplay.textContent = area > 0 ? area.toFixed(2) + ' m²' : '-- m²';
    }

    if (lengthInput) lengthInput.addEventListener('input', updateArea);
    if (widthInput) widthInput.addEventListener('input', updateArea);

    // ─ PRODUCT SELECTION ───────────────────────────
    document.querySelectorAll('.product-type-card').forEach(card => {
        card.addEventListener('click', () => {
            document.querySelectorAll('.product-type-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            calcData.product = card.dataset.product;
        });
    });

    // ─ WASTE SLIDER ────────────────────────────────
    const wasteSlider = $('wasteSlider');
    const wasteDisplay = $('wasteDisplay');
    if (wasteSlider) {
        wasteSlider.addEventListener('input', () => {
            calcData.waste = parseInt(wasteSlider.value);
            if (wasteDisplay) wasteDisplay.textContent = calcData.waste + '%';
        });
    }

    // ─ NAVIGATION BUTTONS ──────────────────────────
    const prevBtn = $('calcPrev');
    const nextBtn = $('calcNext');
    const submitBtn = $('calcSubmit');

    if (prevBtn) prevBtn.addEventListener('click', () => showStep(step - 1));
    if (nextBtn) nextBtn.addEventListener('click', () => { if (validateStep(step)) showStep(step + 1); });

    // ─ CALCULATE & SHOW RESULTS ────────────────────
    if (submitBtn) {
        submitBtn.addEventListener('click', () => {
            if (!validateStep(3)) return;
            calculate();
        });
    }

    function calculate() {
        const baseArea = calcData.length * calcData.width;
        const wasteRate = WASTE_RATES[calcData.waste] || 0.10;
        const totalArea = baseArea * (1 + wasteRate);
        const product = PRODUCTS[calcData.product];
        const boxes = Math.ceil(totalArea / product.boxCoverage);
        const priceMin = (totalArea * product.priceMin).toFixed(2);
        const priceMax = (totalArea * product.priceMax).toFixed(2);

        // Display results
        $('resArea').textContent = totalArea.toFixed(2) + ' m²';
        $('resBoxes').textContent = boxes + ' cajas';
        $('resPriceMin').textContent = '$' + parseFloat(priceMin).toLocaleString('es-PA', { minimumFractionDigits: 2 });
        $('resPriceMax').textContent = '$' + parseFloat(priceMax).toLocaleString('es-PA', { minimumFractionDigits: 2 });
        $('resProduct').textContent = product.name;
        $('resRoom').textContent = calcData.room;

        // Build WhatsApp message for CTA
        const waMessage = encodeURIComponent(
            `Hola Super Pisos Panamá! Necesito cotizar:\n` +
            `• Habitación: ${calcData.room}\n` +
            `• Área: ${totalArea.toFixed(2)} m²\n` +
            `• Material: ${product.name}\n` +
            `• Cajas requeridas: ${boxes}\n` +
            `¿Me pueden dar un precio?`
        );
        const waLink = $('resWaLink');
        if (waLink) waLink.href = `https://wa.me/50769999999?text=${waMessage}`;

        // Show results section
        document.querySelector('.calc-steps-container').style.display = 'none';
        document.querySelector('.calc-steps-nav').style.display = 'none';
        const resultsEl = $('calcResults');
        if (resultsEl) { resultsEl.style.display = 'block'; resultsEl.scrollIntoView({ behavior: 'smooth' }); }
    }

    // ─ RESET CALCULATOR ────────────────────────────
    const resetBtn = $('calcReset');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            calcData = { room: '', length: 0, width: 0, product: '', waste: 10 };
            if (lengthInput) lengthInput.value = '';
            if (widthInput) widthInput.value = '';
            if (areaDisplay) areaDisplay.textContent = '-- m²';
            if (wasteSlider) wasteSlider.value = 10;
            if (wasteDisplay) wasteDisplay.textContent = '10%';
            document.querySelectorAll('.room-card, .product-type-card').forEach(c => c.classList.remove('selected'));
            document.querySelector('.calc-steps-container').style.display = 'block';
            document.querySelector('.calc-steps-nav').style.display = 'flex';
            const resultsEl = $('calcResults');
            if (resultsEl) resultsEl.style.display = 'none';
            showStep(1);
        });
    }

    // Init
    if (document.querySelector('.calc-step')) showStep(1);

})();
