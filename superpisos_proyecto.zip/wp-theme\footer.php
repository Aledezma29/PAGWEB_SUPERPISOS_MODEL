<?php
/**
 * Super Pisos Panamá – footer.php
 */
?>
</div><!-- #page-wrapper -->

<footer class="footer" role="contentinfo">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-logo">Super<span>Pisos</span></a>
        <p>Más de 20 años siendo líderes en pisos, azulejos, revestimientos y ventanas en Panamá.</p>
        <div class="footer-social">
          <a href="<?php echo esc_url(get_theme_mod('superpisos_facebook', '#')); ?>" class="social-icon" target="_blank" rel="noopener" aria-label="Facebook">
            <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
          </a>
          <a href="<?php echo esc_url(get_theme_mod('superpisos_instagram', '#')); ?>" class="social-icon" target="_blank" rel="noopener" aria-label="Instagram">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
          </a>
        </div>
      </div>
      <div>
        <div class="footer-title">Productos</div>
        <div class="footer-links">
          <a href="<?php echo esc_url(home_url('/catalogo?cat=porcelanato')); ?>">Porcelanato</a>
          <a href="<?php echo esc_url(home_url('/catalogo?cat=ceramica')); ?>">Cerámica</a>
          <a href="<?php echo esc_url(home_url('/catalogo?cat=madera')); ?>">Madera Laminada</a>
          <a href="<?php echo esc_url(home_url('/catalogo?cat=azulejo')); ?>">Azulejos</a>
          <a href="<?php echo esc_url(home_url('/catalogo?cat=exterior')); ?>">Pisos Exteriores</a>
        </div>
      </div>
      <div>
        <div class="footer-title">Servicios</div>
        <div class="footer-links">
          <a href="<?php echo esc_url(home_url('/calculadora')); ?>">Calculadora m²</a>
          <a href="<?php echo esc_url(home_url('/visualizador')); ?>">Visualizador</a>
          <a href="<?php echo esc_url(home_url('/contacto')); ?>">Cotización Gratis</a>
          <a href="<?php echo esc_url(home_url('/proyectos')); ?>">Proyectos</a>
          <a href="<?php echo esc_url(home_url('/blog')); ?>">Blog</a>
        </div>
      </div>
      <div class="footer-contact">
        <div class="footer-title">Contacto</div>
        <p>📞 <?php echo esc_html(get_theme_mod('superpisos_phone', '+507 6999-9999')); ?></p>
        <p>✉️ <?php echo esc_html(get_theme_mod('superpisos_email', 'info@superpisos.com.pa')); ?></p>
        <p>📍 <?php echo esc_html(get_theme_mod('superpisos_address', 'Av. R.J. Alfaro, Panamá')); ?></p>
        <p>⏰ Lun–Sáb: 8am – 6pm</p>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="footer-bottom">
      <span>© <?php echo esc_html(date('Y')); ?> Super Pisos Panamá. Todos los derechos reservados.</span>
      <span>
        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Privacidad</a> ·
        <a href="<?php echo esc_url(home_url('/terminos')); ?>">Términos</a>
      </span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
