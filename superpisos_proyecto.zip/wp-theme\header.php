<?php
/**
 * Super Pisos Panamá – header.php
 * Global header: SEO head, navbar, WhatsApp float, lead popup
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ████ NAVBAR ████ -->
<nav class="navbar transparent" id="navbar" aria-label="Navegación principal">
  <div class="navbar-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-logo">
      Super<span>Pisos</span>
    </a>
    <?php
wp_nav_menu([
    'theme_location' => 'primary',
    'container' => 'ul',
    'menu_class' => 'nav-links',
    'fallback_cb' => function () { ?>
        <ul class="nav-links">
          <li><a href="<?php echo esc_url(home_url('/catalogo')); ?>" class="nav-link">Catálogo</a></li>
          <li><a href="<?php echo esc_url(home_url('/calculadora')); ?>" class="nav-link">Calculadora</a></li>
          <li><a href="<?php echo esc_url(home_url('/visualizador')); ?>" class="nav-link">Visualizador</a></li>
          <li><a href="<?php echo esc_url(home_url('/proyectos')); ?>" class="nav-link">Proyectos</a></li>
          <li><a href="<?php echo esc_url(home_url('/blog')); ?>" class="nav-link">Blog</a></li>
          <li><a href="<?php echo esc_url(home_url('/tiendas')); ?>" class="nav-link">Tiendas</a></li>
        </ul>
      <?php
    },
]);
?>
    <a href="<?php echo esc_url(home_url('/contacto')); ?>" class="btn btn-primary nav-cta">Cotiza Gratis</a>
    <button class="hamburger" id="hamburger" aria-label="Menú" aria-expanded="false" aria-controls="mobileNav">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile Nav -->
<nav class="mobile-nav" id="mobileNav" aria-label="Navegación móvil">
  <a href="<?php echo esc_url(home_url('/catalogo')); ?>" class="nav-link">Catálogo</a>
  <a href="<?php echo esc_url(home_url('/calculadora')); ?>" class="nav-link">Calculadora</a>
  <a href="<?php echo esc_url(home_url('/visualizador')); ?>" class="nav-link">Visualizador</a>
  <a href="<?php echo esc_url(home_url('/proyectos')); ?>" class="nav-link">Proyectos</a>
  <a href="<?php echo esc_url(home_url('/blog')); ?>" class="nav-link">Blog</a>
  <a href="<?php echo esc_url(home_url('/tiendas')); ?>" class="nav-link">Tiendas</a>
  <a href="<?php echo esc_url(home_url('/contacto')); ?>" class="btn btn-primary btn-lg" style="margin-top:2rem;">Cotiza Gratis</a>
</nav>

<!-- ████ WHATSAPP FLOAT ████ -->
<a href="<?php echo esc_url(get_theme_mod('superpisos_wa_url', 'https://wa.me/50769999999?text=Hola!')); ?>"
   target="_blank" rel="noopener" id="wa-float" aria-label="Chat por WhatsApp">
  <span class="wa-tooltip">¡Chatea con nosotros!</span>
  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
</a>

<!-- ████ LEAD POPUP ████ -->
<div class="popup-overlay" id="leadPopup" role="dialog" aria-modal="true" aria-labelledby="popupTitle">
  <div class="popup-box">
    <button id="popupClose" class="popup-close" aria-label="Cerrar">×</button>
    <div class="popup-img" style="height:160px;overflow:hidden;background:#f5f0eb;">
      <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/hero.png'); ?>"
           alt="Descuento Super Pisos" style="width:100%;height:100%;object-fit:cover;">
    </div>
    <div class="popup-body">
      <div class="badge badge-primary mb-4">Oferta exclusiva</div>
      <h2 id="popupTitle" class="popup-title">5% de descuento<br>en tu primera compra</h2>
      <p class="popup-desc">Suscríbete al boletín y recibe tu código al instante.</p>
      <form id="popupForm" class="popup-form mt-6">
        <input type="email" placeholder="Tu correo electrónico" required class="form-control">
        <button type="submit" class="btn btn-primary btn-full mt-3">Quiero mi 5% →</button>
      </form>
      <div id="popupSuccess"></div>
      <p class="popup-terms">Al suscribirte aceptas nuestra <a href="<?php echo esc_url(get_privacy_policy_url()); ?>">política de privacidad</a>.</p>
    </div>
  </div>
</div>

<!-- Scroll Top -->
<button id="scrollTop" aria-label="Volver arriba">↑</button>

<div id="page-wrapper">
